package "Install Emacs" do
  package_name "emacs"
end  
